Car rental reservation system
Allows to customer to register/login
Choose car what he/she wants to used.
Then check his/her profile and history.
Send message to Admin/staff for further inquiry.

User types : user and admin

Admin can view all transaction like reservation/reports
Customers Informations
Receive and send messages to customers.
Add/Edit/Delete Cars information

Basic Message System that will let customer message the admin.
